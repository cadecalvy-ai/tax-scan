FICTIONAL TEST DATA - not real people or returns.
Unzip, then drag the sample-clients folder (or any client folder inside it) onto Tax Scan.
